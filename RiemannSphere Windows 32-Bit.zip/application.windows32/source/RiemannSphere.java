import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class RiemannSphere extends PApplet {

int hermiteOrder = 0;
final int MENUTEXTSIZE = 20;
int SPINBOXSIZE = 360;

ComplexColorMap[] cmaps;
InteractableFunction[] interactables;
InteractableFunction activeFunc;
ListMenu flist;

int activeCmap = 0;
ComplexPlane plane;
final float sphereRadius = 100;
float spheriness = 0f;
final int DETAIL = 521;
final double RANGE = 20;
float camAzimuth = 0;
float camElevation = 0;
float camDistance = sphereRadius;
float startDistance;
final float camSensitivity = 1f/100f;
float heightScale = sphereRadius/10f;
int colorScale = 1;
float oldHeightScale;
int turningA = 0;
int turningE = 0;
int switchingM = 0;
int hudBack = color(200,100,255,50);
int hudFront = color(255);
boolean showFuncMenu = false;
boolean interactableMode = false;
PFont fixed,thin;

public void setup(){
  
  //size(1000,800,P3D);
  hint(DISABLE_OPENGL_ERRORS);
  
  SPINBOXSIZE = min(width,height) / 5;
  plane = new ComplexPlane(RANGE,DETAIL);
  plane.applyFunction(new CIdentity());
  refreshColormap();
  interactables = new InteractableFunction[3];
  interactables[0] = new Binomial(plane,cmaps[activeCmap],SPINBOXSIZE);
  interactables[1] = new MobiusTransform(plane,cmaps[activeCmap],SPINBOXSIZE);
  interactables[2] = new BesselFirst(plane,cmaps[activeCmap],SPINBOXSIZE);
  
  startDistance = (height/2.0f) / tan(PI/6.0f);
  
  fixed = createFont("Consolas",28);
  thin = createFont("Calibri Light",16);
  flist = createFunctionList(interactables,plane,MENUTEXTSIZE);
}

public void draw(){
  background(15,15,25);
  
  pushMatrix();
    translate(width/2,height/2,-camDistance);
    rotateX(camElevation);
    rotateY(camAzimuth);
    
    plane.show(sphereRadius,heightScale,spheriness,cmaps[activeCmap]);
    if(spheriness != 0){  
      strokeWeight(spheriness*2);
      stroke(255,0,0,spheriness*255);
      line(-width,0,0,width,0,0);
      stroke(0,255,0,spheriness*255);
      line(0,-width,0,0,width,0);
      stroke(0,0,255,spheriness*255);
      line(0,0,-width,0,0,width);
    }
  popMatrix();
  
  //HUD
  hint(DISABLE_DEPTH_TEST);
  textFont(fixed);
  noStroke();
  textAlign(LEFT);
  textSize(28);
  rectMode(CORNER);
  fill(hudBack);
  rect(5,10,plane.currentFunction.name().length() * 20 + 20,40);
  fill(hudFront);
  text(plane.currentFunction.name(),20,40);
  fill(hudBack);
  rect(5,60,160,40);
  fill(hudFront);
  text("GridScale:" + ((colorScale>0)?colorScale:"1/" + (-colorScale)),10,90);
  
  if(showFuncMenu){
    if(flist.show()){//if an item is selected
      showFuncMenu = false;
    }
  }
  textFont(thin);
  if(interactableMode){
    activeFunc.show(activeCmap == 2);
  }
  
  hint(ENABLE_DEPTH_TEST);
  
  //apply currently active smooth changes like camera and ball<>plane
  if (turningA != 0){
    camAzimuth += turningA*0.1f;
    camAzimuth = (camAzimuth%TAU + TAU) % TAU;
  }
  if (turningE != 0){
    camElevation += turningE*0.125f;
    camElevation = constrain(camElevation,-PI/2f,PI/2f);
  }
  if (switchingM != 0){
    spheriness += switchingM * 0.125f/4;
    if(spheriness < 0){
       spheriness = 0;
       switchingM = 0;
    } else if (spheriness > 1){
       spheriness = 1;
       switchingM = 0;
    }
  }
}

public void refreshColormap(){
  float scaling = (colorScale > 0)? colorScale : -1f/colorScale;
  cmaps = new ComplexColorMap[4];
  cmaps[0] = new ArgandToHueBright(scaling); 
  cmaps[1] = new ArgandGrid(scaling,scaling);
  cmaps[2] = new ArgandPolar(scaling,scaling,8);
  cmaps[3] = new ArgandToYCoCg(scaling);
}

public void normalMode(){
  interactableMode = false;
}

public void interactableMode(InteractableFunction function){
  interactableMode = true;
  activeFunc = function;
  activeFunc.reColorise(cmaps[activeCmap]);
}

public void mouseWheel(MouseEvent e){
  camDistance += 10f*e.getCount();
  //camDistance = constrain(camDistance,-startDistance + sphereRadius, 2 * sphereRadius);
  camDistance = constrain(camDistance,-startDistance + sphereRadius, sphereRadius*1000);
}

public void mouseDragged(){
  if((interactableMode && activeFunc.usingMouse())){
    //prevents mouse from controlling camera while using a spinbox
    return;
  }
  camAzimuth   += (mouseX - pmouseX)*camSensitivity;
  camElevation -= (mouseY - pmouseY)*camSensitivity;
  camAzimuth = (camAzimuth%TAU + TAU) % TAU;
  camElevation = constrain(camElevation,-PI/2f,PI/2f);
  
}

public void keyPressed(){
  if (key == CODED){
    if (keyCode == UP){
      turningE = -1;
      return;
    } else if (keyCode == DOWN){
      turningE = 1;
      return;
    } else if (keyCode == LEFT){
      turningA = 1;
      return;
    } else if (keyCode == RIGHT){
      turningA = -1;
      return;
    }
  }
  switch(key){
    case '\t':
      showFuncMenu = !showFuncMenu;
      break;
    case '-':
      hermiteOrder--;
      if(hermiteOrder < 0){hermiteOrder = 0;}
      plane.applyFunction(new CHermiteFunction(hermiteOrder));
      break;
    case '=':
      hermiteOrder++;
      plane.applyFunction(new CHermiteFunction(hermiteOrder));
      break;
    case '[':
      heightScale *= 0.8f;
      if(heightScale < 1){heightScale = 1;}
      break;
    case ']':
      heightScale *= 1.25f;
      break;
    case '{':
      colorScale--;
      if(colorScale == 0){colorScale = -2;}
      refreshColormap();
      activeFunc.reColorise(cmaps[activeCmap]);
      break;
    case '}':
      colorScale++;
      if(colorScale == -1){colorScale = 1;}
      refreshColormap();
      activeFunc.reColorise(cmaps[activeCmap]);
      break;
    case '\'':// '
      if(heightScale==0){
        heightScale = oldHeightScale;
      } else {
        oldHeightScale = heightScale;
        heightScale = 0;
      }
      break;
    case 'P':
    case 'p':
      if (switchingM == 1){
        switchingM = -1;
      } else if (switchingM == -1){
        switchingM = 1;
      } else if (spheriness == 0){
        switchingM = 1;
      } else if (spheriness == 1){
        switchingM = -1;
      }
      break;
    case '#':
      activeCmap = (activeCmap+1) % cmaps.length;
      activeFunc.reColorise(cmaps[activeCmap]);
      break;
    case '~':
      activeCmap = (activeCmap-1 + cmaps.length) % cmaps.length;
      activeFunc.reColorise(cmaps[activeCmap]);
      break;
  }
}

public void keyReleased(){
  if (key == CODED){
      if (keyCode == UP || keyCode == DOWN){
        turningE = 0;
        return;
      } else if (keyCode == LEFT || keyCode == RIGHT){
        turningA = 0;
        return;
      }
    }
}
public int YCoCg(float Y, float Co, float Cg){return YCoCg(Y,Co,Cg,1f);}
public int YCoCg(float Y, float Co, float Cg,float alpha){
  //Y:[0,1] ;  Co,Cg:[-0.5,0.5]
  float tmp =     Y   -  Cg;
  float R = 255f*(tmp +  Co);
  float G = 255f*(Y   +  Cg);
  float B = 255f*(tmp -  Co);
  return color(R,G,B,255f*alpha);  
}

public float[] inverseYCoCg(int col){return inverseYCoCg(red(col),green(col),blue(col));}
public float[] inverseYCoCg(float R,float G, float B){
  R /= 2f*255f;
  G /= 2f*255f;
  B /= 2f*255f;
  
  float[] ycocg = {0.5f*(R+B) + G,
                   (R-B),
                   G - 0.5f*(R+B)};
  return ycocg;
}

public float[] inverseHSL(int col){return inverseHSL(red(col),green(col),blue(col));}
public float[] inverseHSL(float R,float G, float B){
  R /= 255f;
  G /= 255f;
  B /= 255f;
  final float Cmax = max(R,G,B);
  final float Cmin = min(R,G,B);
  final float delta = Cmax - Cmin;
  final float L = 0.5f*(Cmax + Cmin);
  float H,S;
  if (delta==0){
    H = 0f;
    S = 0f;
  } else {
    S = delta/(1f-abs(2*L-1f));
    final float sect = PI/3;
    if (Cmax == R){
      H = sect*( ( (G-B)/delta ) % 6 );
    } else if (Cmax == G){
      H = sect*( ( (B-R)/delta ) + 2 );
    } else if (Cmax == B){
      H = sect*( ( (R-G)/delta ) + 4 );      
    } else {
      throw new RuntimeException("Impossible colour, unreachable code with RGB: (" + R + "," + G + "," + B + ")");
    }
  }
  
  float[] hsl = {H,S,L};
  return hsl;
}


public int HSL(float H, float S, float L) {return HSL(H,S,L,1);}
public int HSL(float H, float S, float L,float alpha) {
  //L and S in [0,1], H in [0,2pi]
  H = ((H%TAU)+TAU)%TAU;
  float C = (1 - abs(2*L - 1)) * S;
  float Hp = 3*H / PI;
  float X = C*(1 - abs((Hp % 2) - 1));
  float R, G, B;
  if (S == 0 || L==0 || L==1) {
    R=0;
    G=0;
    B=0;
  } else {
    switch(floor(Hp)) {
    case 0:
      R=C; 
      G=X; 
      B=0;
      break;
    case 1:
      R=X; 
      G=C; 
      B=0;
      break;
    case 2:
      R=0; 
      G=C; 
      B=X;
      break;
    case 3:
      R=0; 
      G=X; 
      B=C;
      break;
    case 4:
      R=X; 
      G=0; 
      B=C;
      break;
    case 5:
      R=C; 
      G=0; 
      B=X;
      break;
    default:
      R=0; 
      G=0; 
      B=0;
    }
  }
  float m = L - 0.5f*C;
  return color(255*(R+m), 255*(G+m), 255*(B+m),255*alpha);
}

abstract class RealColorMap {
  public abstract int map(double t);
}

abstract class ComplexColorMap {
  public abstract int map(Complex z);
}

class ReImtoRB extends ComplexColorMap {
  double scalefactor;
  ReImtoRB(double threshold) {
    scalefactor=1/threshold;
  }

  public int map(Complex z) {
    if (z.isNaN()) {
      return color(127);
    }
    float r = (float)( 255 * Math.max( 1 - Math.abs(z.re)*scalefactor , 0 ) );
    float b = (float)( 255 * Math.max( 1 - Math.abs(z.im)*scalefactor , 0 ) );
    return color(r, 0, b);
  }
}

class ArgandToHueBright extends ComplexColorMap {
  double maxExpected;
  ArgandToHueBright(double _maxExpected) {
    maxExpected=_maxExpected;
  }
  public int map(Complex z) {
    if (z.isNaN()) {
      return color(127);
    }
    final float hue = (float)(z.arg()%TAU + TAU) % TAU;
    final double mag = z.mag();
    float l;
    if (mag <= maxExpected) {
      l = (float)(0.5d*mag/maxExpected);
    } else {
      l = (float)(0.5d*(2d - (maxExpected/(Math.log(mag - maxExpected + 1) + maxExpected))));
    }
    return HSL(hue, 1, l);
  }
}
class ArgandGrid extends ComplexColorMap {
  double maxExpected,gridsize;
  ArgandGrid(double _maxExpected,double _gridsize) {
    maxExpected=_maxExpected;
    gridsize = _gridsize;
  }
  public int map(Complex z) {
    if (z.isNaN()) {
      return color(127);
    }
    final float hue = (float)(z.arg()%TAU + TAU) % TAU;
    final double mag = z.mag();
    double gridnessX = Math.abs(z.re/gridsize - Math.round(z.re/gridsize));
    double gridnessY = Math.abs(z.im/gridsize - Math.round(z.im/gridsize));
    double gridness = Math.sqrt(Math.min(gridnessX , gridnessY))  + 0.2f;
    float l;
    if (mag <= maxExpected) {
      l = (float)(0.5d*mag/maxExpected);
    } else {
      l = (float)(0.5d*(2d - (maxExpected/(Math.log(mag - maxExpected + 1) + maxExpected))));
    }
    l *= gridness;
    return HSL(hue, 1, l);
  }
}

class ArgandPolar extends ComplexColorMap {
  double maxExpected,radialGrid,dTheta;
  ArgandPolar(double _maxExpected,double _radialGrid, int angles) {
    maxExpected=_maxExpected;
    radialGrid = _radialGrid;
    dTheta = TAU / angles;
  }
  public int map(Complex z) {
    if (z.isNaN()) {
      return color(127);
    }
    final float hue = (float)(z.arg()%TAU + TAU) % TAU;
    final double mag = z.mag();
    final double arg = z.arg();
    double gridnessM = Math.abs(mag/radialGrid - Math.round(mag/radialGrid));
    double gridnessA = Math.abs(arg/dTheta - Math.round(arg/dTheta));
    double gridness = Math.sqrt(Math.min(gridnessM , gridnessA)) + 0.2f;
    float l;
    if (mag <= maxExpected) {
      l = (float)(0.5d*mag/maxExpected);
    } else {
      l = (float)(0.5d*(2d - (maxExpected/(Math.log(mag - maxExpected + 1) + maxExpected))));
    }
    l *= gridness;
    return HSL(hue, 1, l);
  }
}


class ArgandToYCoCg extends ComplexColorMap {
  double maxExpected;
  float chromaNormalisationFactor;
  ArgandToYCoCg(double _maxExpected) {
    maxExpected=_maxExpected;
    chromaNormalisationFactor = 0.5f / chromaFunction((float)maxExpected);
  }
  public float chromaFunction(float x){
    float c = sqrt((float)(maxExpected*maxExpected) - 1);
    //float c = (float)maxExpected;
    float xSubc = x-c;
    return x / (1 + xSubc*xSubc);
  }
  public int map(Complex z) {
    if (z.isNaN()) {
      return color(127);
    }
    final float theta = (float)(z.arg()%TAU + TAU) % TAU;
    final double mag = z.mag();
    float Y;
    float chroma = chromaFunction((float)mag)*chromaNormalisationFactor;
    if (mag <= maxExpected) {
      Y = max(0 ,min((float)(0.5d*mag/maxExpected),1));
      
    } else {
      Y = (float)(0.5d*(2d - (maxExpected/(Math.log(mag - maxExpected + 1) + maxExpected))));
      
    }
    return YCoCg(Y,chroma*sin(theta),chroma*cos(theta));
  }
}
final double degrees = Math.PI/180d;



public Complex fromPolar(double arg){return fromPolar(1d,arg);}
public Complex fromPolar(double mag,double arg){
  //allows definition of complex numbers by polar representation
  return new Complex(mag*Math.cos(arg),mag*Math.sin(arg));
}

public Complex lerp(Complex a, Complex b, double t){return a.add(b.sub(a).mult(t));}
public Complex lerp(Complex a, Complex b, Complex t){return a.add(b.sub(a).mult(t));}

public Complex[] linspaceC(double low, double high, int len){return linspaceC(new Complex(low,0),new Complex(high,0),len);}
public Complex[] linspaceC(Complex low, Complex high,int len) {
    Complex[] arr = new Complex[len];
    Complex step = high.sub(low).divBy(len-1);
    for (int i = 0; i < len; i++) {arr[i] = low.add(step.mult(i));}
    return arr;
}

public Complex[] arrayOfZeros(int n){
  Complex[] out = new Complex[n];
  for(int i=0; i<n;i++){
    out[i] = new Complex(0,0);
  }
  return out;
}
public Complex[] arrayOfOnes(int n){
  Complex[] out = new Complex[n];
  for(int i=0; i<n;i++){
    out[i] = new Complex(1,0);
  }
  return out;
}

public Complex sawtooth(Complex z){
  //returns sawtooth going (0,0)=>(1,0.5)=>(-1.0.5)=>(1,0)...
  return z.sub(z.round()).mult(2d);}

public Complex gaussian(Complex z){
  return z.cmag2().neg().exp();
}

public Complex gaussianAtGaussianMultiplesOfN(Complex z, Complex n){
    //puts a nice normal bump at all gaussian integer multiples of n, 0ish at other integers
    return gaussian( n.mult(sawtooth(z.divBy(n))) );}


class Complex{
  double re;
  double im;
  
  
  Complex(double r, double i){re = r; im = i;}
  
  public String toString(){
    if(re==0){
      if(im < 0){return "(-i" + Double.toString(-im) + ")";}
      return "i" + Double.toString(im);
    } else if (im==0){
      return Double.toString(re);
    } else {
      if (im < 0){
        String RE = Double.toString(re);
        String IM = " - i" + Double.toString(-im);
        return "(" + RE + IM + ")";
      } else {
        String RE = Double.toString(re);
        String IM = " + i" + Double.toString(im);
        return "(" + RE + IM + ")";
      }
    }
  }
  
  //=================ATTRIBUTES and BASIC UNITARY Operators==========================
  
  public boolean isNaN(){return Double.isNaN(re) || Double.isNaN(im);}
  
  public Complex neg(){return new Complex(-re,-im);}//negative
  public Complex conj(){return new Complex(re,-im);}//complex conjugate
  
  public double mag2() {return re*re + im*im;}//magnitude squared
  public Complex cmag2(){return new Complex(mag2(),0);}
  
  public double mag() {return Math.sqrt(re*re + im*im);}//magnitude BEWARE OVERFLOW
  public Complex cmag() {return new Complex(mag(),0);}
  public double hypot() {return Math.hypot(re,im);}//magnitude without overflow
  public Complex chypot() {return new Complex(Math.hypot(re,im),0);}
  
  public double arg(){
    if(im == 0){return (re>=0)?0:Math.PI;}
    return Math.atan2(im,re);
  }
  public Complex carg(){return new Complex(arg(),0);}
  
  public Complex reciprocal(){
    final double len2 = mag2();
    return new Complex(re/len2,-im/len2);
  }
  public Complex normalised(){
    final double len = mag(); 
    if(len==0){return new Complex(0,0);}
    return new Complex(re/len,im/len);
  }
  public Complex normalisedBIG(){
    final double len = hypot(); 
    if(len==0){return new Complex(0,0);}
    return new Complex(re/len,im/len);
  }
  
  
  //=============ARITHMETIC AND BINARY OPERATORS=====================================
  //comparison
  public boolean equals(Complex other) {return re==other.re && im==other.im;}
  public boolean equals(Complex other, double within){
     double redif2 =re - other.re;
     double imdif2 =im - other.im;
     redif2 *= redif2;
     imdif2 *= imdif2;
     within *= within;
    return  redif2 < within && imdif2 < within;
  }
  
  //addition
  public Complex add(double other){return new Complex(re + other,im);}
  public Complex add(Complex other){return new Complex(re + other.re, im + other.im);}
  
  //multiplication
  public Complex mult(double other) {return new Complex(re*other,im*other);}
  public Complex mult(Complex other){
    final double rOut = re * other.re  -  im*other.im;
    final double iOut = re * other.im  +  im*other.re;  
    return new Complex(rOut,iOut);
  }
  
  //subtraction
  public Complex sub(double other){return new Complex(re - other,im);}//subtracts other from this
  public Complex sub(Complex other){return new Complex(re-other.re,im - other.im);}
  public Complex subFrom(double other){return new Complex(other - re,-im);}//subtracts this from other
  public Complex subFrom(Complex other){return new Complex(other.re - re, other.im - im);}
  
  //division
  public Complex div(double numerator){return reciprocal().mult(numerator);}//divides numerator by this
  public Complex div(Complex numerator){return reciprocal().mult(numerator);}
  public Complex divBy(double denominator){return new Complex(re/denominator,im/denominator);}//divides this by denominator
  public Complex divBy(Complex denominator){return mult(denominator.reciprocal());}
  
  //======================EXPONENTS AND POWERS=============================
  public Complex square(){return new Complex(re*re - im*im, 2*re*im);}
  public Complex cube(){return new Complex(re*re*re - 3*re*im*im , 3*re*re*im - im*im*im);}
  
  //natural base e stuff
  public Complex exp(){
    if(im==0){return new Complex(Math.exp(re),0);}
    return fromPolar(Math.exp(re),im);
  }
  public Complex ln(){return ln(0);}//fast log without intermediate overflow protection
  public Complex ln(int branch) {return new Complex(0.5f*Math.log(re*re + im*im),arg() + 2*Math.PI*branch);}
  public Complex lnBIG(){return lnBIG(0);}//log with intermediate overflow protection
  public Complex lnBIG(int branch) {return new Complex(Math.log(Math.hypot(re,im)),arg() + 2*Math.PI*branch);}
  
  //arbitrary base logs
  public Complex log(Complex base){return log(base,0);}
  public Complex log(Complex base,int branch){return ln(branch).divBy(base.ln(branch));}
  public Complex log(double base){return log(new Complex(base,0d),0);}
  public Complex log(double base,int branch){return log(new Complex(base,0d),branch);}
  
  //arbitrary base exponents
  public Complex raiseTo(double power){return raiseTo(new Complex(power,0d),0);}
  public Complex raiseTo(double power,int branch){return raiseTo(new Complex(power,0d),branch);}
  public Complex raiseTo(Complex power){return raiseTo(power,0);}
  public Complex raiseTo(Complex power,int branch){
    if (re == 0 && im == 0){//when base equals 0
      if (power.re > 0){return new Complex(0,0);}
      else {return new Complex(Double.NaN,Double.NaN);}
    }else if(power.im == 0 && power.re%2==0 && re<0 && im==0){//raising negative number to even power
      return new Complex(Math.pow(-re,power.re),2*branch);
    }
    return ln(branch).mult(power).exp();
  }
  
  public Complex raiseBy(double base){return (new Complex(base,0)).raiseTo(this,0);}
  public Complex raiseBy(Complex base){return base.raiseTo(this,0);}
  public Complex raiseBy(double base,int branch){return (new Complex(base,0)).raiseTo(this,branch);}
  public Complex raiseBy(Complex base,int branch){return base.raiseTo(this,branch);}
  
  public Complex root(double radicand){return raiseTo(1d/radicand,0);}
  public Complex root(double radicand, int branch){return raiseTo(1d/radicand,branch);}
  public Complex root(Complex radicand){return raiseTo(radicand.reciprocal(),0);}
  public Complex root(Complex radicand,int branch){return raiseTo(radicand.reciprocal(),branch);}
  
  public Complex sqrt(){return sqrt(0);}
  public Complex sqrt(int branch){return fromPolar(Math.sqrt(mag()),0.5f*arg() + Math.PI*branch);}
  public Complex sqrtBIG(int branch){return fromPolar(Math.sqrt(hypot()),0.5f*arg() + Math.PI*branch);}
  
  
  //=======================TRIGONOMETRIC AND HYPERBOLIC STUFF=================================
  //trig functions
  public Complex sin(){
    if (im==0){return new Complex(Math.sin(re),0);}
    final Complex I = new Complex(0,1);
    return mult(I).exp().sub(mult(I.neg()).exp()).divBy(I.mult(2));}
  public Complex cos(){
    if (im==0){return new Complex(Math.cos(re),0);}
    final Complex I = new Complex(0,1);
    return mult(I).exp().add(mult(I.neg()).exp()).divBy(2);}
  public Complex tan(){
    if (im==0){return new Complex(Math.tan(re),0);}
    return sin().divBy(cos());}
  
  //hyperbolic functions  
  public Complex sinh(){
    if (im==0){return new Complex(Math.sinh(re),0);}
    return exp().sub(neg().exp()).divBy(2);}
  public Complex cosh(){
    if (im==0){return new Complex(Math.cosh(re),0);}
    return exp().add(neg().exp()).divBy(2);}
  public Complex tanh(){
    if (im==0){return new Complex(Math.tanh(re),0);}
    return sinh().divBy(cosh());}
  
  //inverse trig functions
  public Complex asin(int branch){
    final Complex I = new Complex(0,1);
    return square().neg().add(1).sqrt(branch).add(mult(I)).ln(branch).mult(I.neg());}
  public Complex acos(int branch){return this.asin(branch).neg().add(Math.PI/2);}
  public Complex atan(int branch){
    final Complex I = new Complex(0,1);
    return I.divBy(2).mult(add(I).divBy(subFrom(I)).ln(branch));}
  
  //inverse hyperbolic functions
  public Complex asinh(int branch){return add(square().add(1).sqrt(branch)).ln(branch);}
  public Complex acosh(int branch){return add(this.sub(1).sqrt(branch).mult(add(1).sqrt(branch))).ln(branch);}
  public Complex atanh(int branch){return mult(new Complex(0,1)).atan(branch).mult(new Complex(0,-1));}
  
  
  //=======================GAUSSIAN INTEGERS STUFF=================================
  public Complex round(){
    //rounds up (towards positive inf) on half integers
    return new Complex(Math.round(re),Math.round(im));
  }
  public Complex roundPolar(double snapAngle){
    //rounds up (towards positive inf) on half integers
    double oldArg = arg();
    double newArg = oldArg - (oldArg%snapAngle);
    double newMag = Math.round(mag());
    return fromPolar(newMag,newArg);
  }
  public Complex roundPolarHarmonic(double snapAngle){
    //rounds up (towards positive inf) on half integers, for |z|<1 this rounds to the nears 1/n;
    double oldArg = arg();
    double newArg = snapAngle * Math.round(oldArg/snapAngle);
    double oldMag = mag();
    double newMag;
    if(oldMag >= 1){
      newMag = Math.round(oldMag);
    } else {
      newMag = 1d / Math.round(1d/oldMag);
    }
    return fromPolar(newMag,newArg);
  }
  
  public Complex[] roundAndError(){
    final double rre = Math.round(re);
    final double rim = Math.round(im);
    Complex[] out = {new Complex(rre,rim),new Complex(re-rre,im-rim)};
    return out;
  }
  public Complex floor(){
    return new Complex(Math.floor(re),Math.floor(im));
  }
  
  public Complex[] floorAndError(){
    final double rre = Math.floor(re);
    final double rim = Math.floor(im);
    Complex[] out = {new Complex(rre,rim),new Complex(re-rre,im-rim)};
    return out;
  }
  
  public Complex modBy(Complex other){
    return divBy(other).floorAndError()[1].mult(other);
  }
  
  public Complex[] divmodBy(Complex other){
    Complex trueQuotient = divBy(other);
    Complex[] qNr = trueQuotient.floorAndError();
    qNr[1] = qNr[1].mult(other);
    return qNr;
  }
  //===============PRETENDING THERE'S ORDERING STUFF===========================
  public Complex elementAbs(){
    return new Complex(Math.abs(re),Math.abs(im));
  }
}
class ProductWrapper implements ComplexFunction{
  ComplexFunction[] functions;
  ProductWrapper(ComplexFunction f1,ComplexFunction f2){
    functions = new ComplexFunction[2];
    functions[0] = f1;
    functions[1] = f2;
  }
  ProductWrapper(ComplexFunction[] funcs){functions = funcs;}
  public String name(){
    String out = "";
    for(ComplexFunction func : functions){
      out += ("(" + func.name() + ")") + " * ";
    }
    return out.substring(0,out.length() - 3);
  }
  
  public Complex f(Complex z){
    Complex out = new Complex(1,0);
    for(ComplexFunction func : functions){
      out = out.mult(func.f(z));
    }
    return out;
  }
}
class QuotientWrapper implements ComplexFunction{
  ComplexFunction N,D;
  QuotientWrapper(ComplexFunction num,ComplexFunction den){
    N = num;
    D = den;
  }
  public String name(){
    return "(" + N.name() + ") / (" + D.name() + ")";
  }
  
  public Complex f(Complex z){
    return N.f(z).divBy(D.f(z));
  }
}


class ComposeWrapper implements ComplexFunction{
  ComplexFunction outer,inner;
  ComposeWrapper(ComplexFunction outerfunction, ComplexFunction innerfunction){
    outer = outerfunction;
    inner = innerfunction;
  }
  public String name(){return outer.name().replaceAll("z",inner.name());}
  public Complex f(Complex z){return outer.f(inner.f(z));}
  
}
interface ComplexFunction {
  public String name();
  public Complex f(Complex z);
}
class CIdentity implements ComplexFunction{
  public String name(){return "z";}
  public Complex f(Complex z){return z;}
}
class CConstant implements ComplexFunction{
  Complex constant;
  CConstant(Complex c){constant = c;}  
  public String name(){return constant.toString();}
  public Complex f(Complex z){return constant;}
}
class CScale implements ComplexFunction{
  Complex constant;
  CScale(Complex c){constant = c;}  
  public String name(){return constant.toString() + " * z";}
  public Complex f(Complex z){return z.mult(constant);}
}

class CReciprocal implements ComplexFunction{
  public String name(){return "1/z";}
  public Complex f(Complex z){return z.reciprocal();}
}
class CSqrt implements ComplexFunction{
  public String name(){return "sqrt(z)";}
  public Complex f(Complex z){return z.sqrt();}
}


class CSin implements ComplexFunction{
  public String name(){return "sin(z)";}
  public Complex f(Complex z){return z.sin();}
}
class CCos implements ComplexFunction{
  public String name(){return "cos(z)";}
  public Complex f(Complex z){return z.cos();}
}
class CTan implements ComplexFunction{
  public String name(){return "tan(z)";}
  public Complex f(Complex z){return z.tan();}
}
class CASin implements ComplexFunction{
  public String name(){return "asin(z)";}
  public Complex f(Complex z){return z.asin(0);}
}
class CACos implements ComplexFunction{
  public String name(){return "acos(z)";}
  public Complex f(Complex z){return z.acos(0);}
}
class CATan implements ComplexFunction{
  public String name(){return "atan(z)";}
  public Complex f(Complex z){return z.atan(0);}
}


class CSinh implements ComplexFunction{
  public String name(){return "sinh(z)";}
  public Complex f(Complex z){return z.sinh();}
}
class CCosh implements ComplexFunction{
  public String name(){return "cosh(z)";}
  public Complex f(Complex z){return z.cosh();}
}
class CTanh implements ComplexFunction{
  public String name(){return "tanh(z)";}
  public Complex f(Complex z){return z.tanh();}
}
class CASinh implements ComplexFunction{
  public String name(){return "asinh(z)";}
  public Complex f(Complex z){return z.asinh(0);}
}
class CACosh implements ComplexFunction{
  public String name(){return "acosh(z)";}
  public Complex f(Complex z){return z.acosh(0);}
}
class CATanh implements ComplexFunction{
  public String name(){return "atanh(z)";}
  public Complex f(Complex z){return z.atanh(0);}
}

class CQuartish implements ComplexFunction{
    Complex ONE = new Complex(1,0);
    Complex ZERO = new Complex(0,0);
    Complex[] coefsN = {ONE,ZERO,ONE};
    Complex[] coefsD = {ONE.neg(),ZERO,ONE};
    ComplexFunction ratio = new QuotientWrapper(new CPolynomial(coefsN),new CPolynomial(coefsD));
    public String name(){return ratio.name();}
    public Complex f(Complex z){return ratio.f(z);}
}

class CSquare implements ComplexFunction{
  public String name(){return "z^2";}
  public Complex f(Complex z){return z.square();}
}
class CCube implements ComplexFunction{
  public String name(){return "z^3";}
  public Complex f(Complex z){return z.cube();}
}

class CPow implements ComplexFunction{
  int power;
  CPow(int pow){power = pow;}
  public String name(){return "z^" + power;}
  public Complex f(Complex z){return z.raiseTo(power);}
}

class CExp implements ComplexFunction{
  public String name(){return "exp(z)";}
  public Complex f(Complex z){return z.exp();}
}
class CLog implements ComplexFunction{
  public String name(){return "ln(z)";}
  public Complex f(Complex z){return z.ln();}
}
class CGauss implements ComplexFunction{
  public String name(){return "exp(-z^2)";}
  public Complex f(Complex z){return z.square().neg().exp();}
}
class CGaussAbs implements ComplexFunction{
  public String name(){return "exp(-|z|^2)";}
  public Complex f(Complex z){return z.cmag2().neg().exp();}
}

class CBinet implements ComplexFunction{
  final Complex Phi = new Complex(1.618033988749894d,0); //principal golden ratio
  final Complex phi = new Complex(-0.618033988749894d,0);//"sister" golden ratio
  final double inroot5 = 0.447213595499957d;//1/sqrt(5);
  public String name(){return "Binet(z) (Fibonacci numbers)";}
  public Complex f(Complex z){return Phi.raiseTo(z).sub(phi.raiseTo(z)).mult(inroot5);}
}

class CErf implements ComplexFunction{
  double oneOverDz;
  final double twoOnRootPi = 1.1283791670955125738961589031215451716881012586579977136881714434d;
  CErf(double dz){oneOverDz=1d/dz;}
  
  public String name(){return "erf(z)";}
  public Complex f(Complex z){
    int detail = (int)Math.round(z.mag() * oneOverDz);
    ComplexFunction gaussian = new CGauss();
    IntegralLine line = new ComplexBounds(new Complex(0,0),z);
    Integral integral = new Integral(gaussian,line);
    return integral.evaluateSimpson(detail).mult(twoOnRootPi);
  }
}

class CGamma implements ComplexFunction{
  int detail;
  CGamma(int _detail){detail=_detail;}
  public String name() {return "Gamma(z)";}
  public Complex f(Complex z){      
    ComplexFunction reciprocal = new CReciprocalGamma(detail);
    return reciprocal.f(z).reciprocal();
  }
}


class CReciprocalGamma implements ComplexFunction{
  final double gamma = 0.57721566490153286060d;//euler-mascheroni constant
  int terms;
  CReciprocalGamma(int accuracy){terms = accuracy;}
  public String name(){return "1/Gamma(z)";}
  public Complex f(Complex z){
    Complex out = z.mult(z.mult(gamma).exp());
    for (int n=1; n<terms;n++){
      Complex zOnN = z.divBy(n);
      out = out.mult( zOnN.add(1).mult(zOnN.neg().exp()) );
    }
    return out;
  }
}



class CZeta implements ComplexFunction{
  //Using Helmut Hasse's globally convergent series
  int detail;
  final Complex ZERO = new Complex(0,0);
  final Complex TWO = new Complex(2,0);
  CZeta(int _detail){detail=_detail;}
  public String name() {return "Zeta(z)";}
  public Complex f(Complex s){  
    Complex leading = TWO.raiseTo(s.subFrom(1)).subFrom(1).reciprocal();
    Complex out = ZERO;
    for (int n=0; n<detail; n++){
      Complex binPart = ZERO;
      for (int k=0; k<=n; k++){
        double bin = ((k%2 == 0)?1:-1) * binomial(n,k);
        Complex summand = new Complex(k+1,0).raiseTo(s).reciprocal().mult(bin);
        binPart = binPart.add(summand);
      }
      binPart.re = Math.scalb(binPart.re,-n-1);
      binPart.im = Math.scalb(binPart.im,-n-1);
      out = out.add(binPart);
    }
    return out.mult(leading);
  }
  
  public double binomial(int n, int k){
    double out = 1;
    double N = n;
    for(int i=1; i<=k; i++){
      out *= (N + 1d - i) / i;
    }
    return out;
  }
}

class CHermiteFunction implements ComplexFunction{
  int order;
  ComplexFunction H,G,C,F;
  CHermiteFunction(int n){
    order = n;
    double constant = 1d/Math.sqrt(Math.scalb( Math.sqrt(Math.PI)*factorial(n) , n) );
    H = new CHermitePolynomial(n);
    G = new ComposeWrapper(new CGaussAbs(),new CScale(new Complex(Math.sqrt(2),0)));//exp(z^2 / 2)
    C = new CConstant(new Complex(constant,0));
    ComplexFunction[] factors = {C,G,H};
    F = new ProductWrapper(factors);
  }
  public String name(){return F.name();}
  public Complex f(Complex z){return F.f(z);}
}

class CMandel implements ComplexFunction{
  int iters;
  String name;
  CMandel(int _iters){
    iters = _iters;
    name = "M" + Integer.toString(iters) + "(z)";
    name = name.replaceAll("0", "⁰");    name = name.replaceAll("1", "¹");
    name = name.replaceAll("2", "²");    name = name.replaceAll("3", "³");
    name = name.replaceAll("4", "⁴");    name = name.replaceAll("5", "⁵");
    name = name.replaceAll("6", "⁶");    name = name.replaceAll("7", "⁷");
    name = name.replaceAll("8", "⁸");    name = name.replaceAll("9", "⁹");  
  }
  public String name(){return name;}
  public Complex f(Complex z){
    Complex c = z.mult(1);//creates a copy
    for (int i=0; i<iters; i++){
      z = z.square().add(c);
    }
    return z;
  }
}
class ComplexPlane{
  int detail;
  double r;
  ComplexFunction currentFunction;
  Complex[] zplane;
  Complex[] fplane;
  
  ComplexPlane(double _r, int _detail){
    r = _r;
    detail = _detail;
    currentFunction = new CIdentity();
    //cartesianGrid();
    polarGrid();
  }
  
  public void cartesianGrid(){
    double dz = 2*r/(detail-1);
    zplane = new Complex[detail*detail];
    fplane = new Complex[detail*detail];
    for(int j=0;j<detail;j++){
      for(int i=0;i<detail;i++){
        zplane[i + detail*j] = new Complex(i*dz - r, j*dz - r);
        fplane[i + detail*j] = new Complex(i*dz - r, j*dz - r);
      }
    }
  }
  public void polarGrid(){
    double dAzi = 2d*Math.PI/(detail-2);
    double highestLatitude = Math.atan2(1d - 2d/(r*r + 1d) , 2d*r / (r*r + 1d));
    double dTheta = (Math.PI/2d + highestLatitude) / (detail - 1);
    zplane = new Complex[detail*detail];
    fplane = new Complex[detail*detail];
    for(int j=0;j<detail;j++){
      for(int i=0;i<detail;i++){
        double theta = dTheta*j - Math.PI/2d;
        double azi = i*dAzi;
        double mag = Math.cos(theta) / (1-Math.sin(theta));
        zplane[i + detail*j] = fromPolar(mag,azi);
        fplane[i + detail*j] = fromPolar(mag,azi);
      }
    }
  }
  
  public PVector toHeightmap(Complex z,Complex f, float XZscale,float heightScale){
    return new PVector((float)(XZscale*z.re),(f.isNaN())?(100):(-(float)(f.mag()*heightScale)),-(float)(XZscale*z.im));
  }
  
  public PVector toRiemannSphere(Complex z,float radius){
    PVector out = new PVector();
    double ZMAG2 = z.mag2();
    double ZMAG = Math.sqrt(ZMAG2);
    double ZARG = z.arg();
    //calculate horizontal component
    double r = 2d*ZMAG / (ZMAG2 + 1d);
    out.x =  radius*(float)(r*Math.cos(ZARG));
    out.y = -radius*(float)(1d - 2d/(ZMAG2 + 1));
    out.z = -radius*(float)(r*Math.sin(ZARG));
    return out;
  }
  
  public Complex getZ(int i, int j){return zplane[i + detail*j];}
  public Complex getF(int i, int j){return fplane[i + detail*j];}
  
  public void applyFunction(ComplexFunction func){
    currentFunction = func;
    for(int j=0;j<detail;j++){
      for(int i=0;i<detail;i++){
        fplane[i + detail*j] = func.f(zplane[i + detail*j]);
      }
    }
  }

  public void show(float radius,float heightScale,float spheriness,ComplexColorMap cmap){
    noStroke();
    //strokeWeight(1);
    //stroke(100);
    for(int j=0;j<detail - 1;j++){
      beginShape(TRIANGLE_STRIP);
      for(int i=0;i<detail - 1;i++){
        //the S stands for "south" because these points are 1 down
        Complex  z  = getZ(i,j);
        Complex zS  = getZ(i,j+1);
        Complex  f  = getF(i,j);
        Complex fS  = getF(i,j+1);
        //the ps stands for Point-on-Sphere
        //the pp stands for Point-on-Plane
        PVector ps,psS,pp,ppS,p,pS;
        if(spheriness == 0){
          pp = toHeightmap(z,f,radius,heightScale);
          ppS = toHeightmap(zS,fS,radius,heightScale);
          p = pp;
          pS = ppS;
        } else if (spheriness == 1){
          ps = toRiemannSphere(z,radius);
          psS = toRiemannSphere(zS,radius);
          p = ps;
          pS = psS;
        } else {
          pp = toHeightmap(z,f,radius,heightScale);
          ppS = toHeightmap(zS,fS,radius,heightScale);
          ps = toRiemannSphere(z,radius);
          psS = toRiemannSphere(zS,radius);
          p = pp.lerp(ps,spheriness);
          pS = ppS.lerp(psS,spheriness);
        }
        fill(cmap.map(f));
        vertex(p.x,p.y,p.z);
        fill(cmap.map(fS));
        vertex(pS.x,pS.y,pS.z);
      }
      endShape();
    }
  }
  
}
class CPolynomial implements ComplexFunction{
  Complex[] coefficients;
  CPolynomial(Complex[] c){ coefficients = c; }
  CPolynomial(){coefficients = new Complex[0];}//empty polynomial for extended classes
  public @Override
  String toString(){return name();}
  
  public String name(){
    final Complex ZERO = new Complex(0,0);
    final Complex ONE = new Complex(1,0);
    String out = "";
    for(int i=0;i<coefficients.length;i++){
      if(coefficients[i].equals(ZERO)){
         continue;
      } else if (i==0){
        out += coefficients[i].toString() + " + ";
      } else if (coefficients[i].equals(ONE)){
        out += "z^" + i + " + ";
      } else if (i==0){
        out += coefficients[i].toString() + " + ";
      } else {
        out += coefficients[i].toString() + "z^" + i + " + ";
      }
    }
    out = out.substring(0,out.length() - 3);
    return out;
  }
  
  public Complex f(Complex x){
    Complex out = coefficients[0];
    Complex currentPower = new Complex(1,0);
    final Complex ZERO = new Complex(0,0);
    for(int i=1;i<coefficients.length;i++){
      currentPower = currentPower.mult(x);
      if(!coefficients[i].equals(ZERO)){
        out = out.add( coefficients[i].mult(currentPower) );
      }
    }
    return out;
  }
  
  public CPolynomial add(CPolynomial other){
    int longLength = Math.max(coefficients.length,other.coefficients.length);
    int shortLength = Math.min(coefficients.length,other.coefficients.length);

    Complex[] newCoefs = new Complex[longLength];
    Complex[] shortCoefs, longCoefs;
    if(coefficients.length > other.coefficients.length){
      longCoefs = coefficients;
      shortCoefs = other.coefficients;
    } else {
      shortCoefs = coefficients;
      longCoefs = other.coefficients;
    }
    
    for(int i=0; i<newCoefs.length;i++){
      if (i>=shortLength){
        newCoefs[i] = longCoefs[i];
      } else {
        newCoefs[i] = shortCoefs[i].add(longCoefs[i]);
      }
    }
    return new CPolynomial(newCoefs);
  }
  
  public CPolynomial mult(CPolynomial other){
    final Complex ZERO = new Complex(0,0);
    int thislength = coefficients.length;
    int othrlength = other.coefficients.length;
    Complex[] newCoefs = new Complex[thislength + othrlength - 1];
    for(int i=0; i<thislength; i++){
      for(int j=0; j<thislength; j++){
        if(newCoefs[i+j] == null){newCoefs[i+j] = ZERO;}
        Complex product = coefficients[i].mult(other.coefficients[j]);
        newCoefs[i+j] = newCoefs[i+j].add(product);
      }  
    }
    return new CPolynomial(newCoefs);
  }
  
  public CPolynomial derivative(){
    if(coefficients.length <= 1){
      Complex [] coefs = {new Complex(0,0)};
      return new CPolynomial(coefs);
    }
    Complex[] newcoefs = new Complex[coefficients.length - 1];
    for(int i=0; i<newcoefs.length;i++){
      newcoefs[i] = coefficients[i+1].mult(i+1);
    }
    return new CPolynomial(newcoefs);
  }
  
  public CPolynomial antiderivative(){return antiderivative(new Complex(0,0));}
  public CPolynomial antiderivative(Complex c){
    Complex[] newcoefs = new Complex[coefficients.length + 1];
    newcoefs[0] = c;
    for(int i=0; i < coefficients.length;i++){
      newcoefs[i+1] = coefficients[i].divBy(i + 1);
    }
    return new CPolynomial(newcoefs);
  }
  
  public CPolynomial dx(int n){
    if (n==0){
            return new CPolynomial(coefficients);
    } else if (n==1){
        return derivative();
    } else if (n>0){
        return dx(n-1).derivative();
    } else if (n==-1){
        return antiderivative();
    } else if (n<0){
        return dx(n+1).antiderivative();
    }
    throw new RuntimeException("Should be unreachable. Polynomial derivative dx");
  }
  
}

public CPolynomial fromRoots(Complex[] roots){
  final Complex ONE = new Complex(1,0);
  Complex[] start = {ONE};
  CPolynomial out = new CPolynomial(start);
  for(Complex root: roots){
    Complex[] monoterms = {root.neg(),ONE};
    CPolynomial monomial = new CPolynomial(monoterms);
    out.mult(monomial);
  }
  return out;
}

class CHermitePolynomial extends CPolynomial{
  int order;
  CHermitePolynomial(int n){
    super();
    order = n;
    coefficients = arrayOfZeros(n + 1);
    for(int m=0; m <= n/2; m++){
      int power = n - 2*m;
      int sign = (m%2 == 0)?1:-1; // (-1)^m
      double twoPart = (1L << power); //2^(n-2m)
      double factTop = fallingFactorial(n,n-m); //n!/m!
      double factBottom = factorial(power); // (n-2m)!
      double wholeTerm = sign * (factTop / factBottom) * twoPart;
      coefficients[power] = new Complex(wholeTerm,0);
    }
  }
  public @Override
  String name(){return "H" + order + "(z)";}
}
class ComplexSpinBox{
  final int detailA = 128;//longitude stripes, A stands for azimuth
  final int detailT = 63;//latitude stripes, T stands for Theta(Elevation)
  PGraphics display;
  int[] sphereLUT;
  PVector[] spherePoints;
  double azimuth,elevation;
  PVector screenPos,screenSize;
  boolean dragging = false;
  boolean snapping = false;
  ComplexSpinBox(Complex initialValue,ComplexColorMap cmap,float screenX,float screenY,int sizeX,int sizeY){
    screenPos = new PVector(screenX,screenY);
    screenSize = new PVector(sizeX,sizeY);
    display = createGraphics(sizeX,sizeY,P3D);
    setValue(initialValue);
    reColorise(cmap);
  }
  
  public void reColorise(ComplexColorMap cmap){
    sphereLUT = new int[detailA*detailT];
    spherePoints = new PVector[detailA*detailT];
    final float dAzi = 2f*PI/(detailA-2);
    final float dTheta = PI / (detailT - 1);
    final float r = min(screenSize.x,screenSize.y)/3;
    for(int t=0;t<detailT;t++){
      for(int a=0;a<detailA;a++){
        float theta = dTheta*t - PI/2f;
        float azi = a*dAzi;
        int index = a + t*detailA;
        spherePoints[index] = new PVector(-r*sin(azi)*cos(theta),
                                          -r*sin(theta),
                                          r*cos(azi)*cos(theta));
        if(t == detailT/2){
          sphereLUT[index] = color(0);
        } else if(a == 0 || a == detailA/2 || a==detailA/4 || a==3*detailA/4){
          sphereLUT[index] = color(255);
        } else {
          double mag = Math.cos(theta) / (1-Math.sin(theta));
          if (t == 0){mag=0d;}
          sphereLUT[index] = cmap.map(fromPolar(mag,azi));
        }
      }
    }
    updateGraphics();
  }
  
  public Complex value(){
    double mag = Math.cos(elevation) / (1-Math.sin(elevation));
    if (elevation == -Math.PI/2d){mag=0d;}
    return fromPolar(mag,azimuth);
  }
  
  public void setValue(Complex newVal){
    double ZMAG2 = newVal.mag2();
    double ZMAG = Math.sqrt(ZMAG2);
    //calculate horizontal component
    double r = 2d*ZMAG / (ZMAG2 + 1d);
    double h = 1d - 2d/(ZMAG2 + 1d);
    azimuth = newVal.arg();
    elevation = Math.atan2(h,r);
  }
  
  public boolean mousedOver(){
    final float relX = mouseX - screenPos.x;
    final float relY = mouseY - screenPos.y;
    return 0 < relX && relX < screenSize.x && 0<relY && relY < screenSize.y;
  }
  
  public void updateGraphics(){
    display.beginDraw();
    display.noStroke();
      if(dragging){
        display.background(255,100);
      } else {
        display.background(0,100);
      }
      display.translate(display.width/2f,display.height/2f,0);
      display.rotateX(-(float)elevation);
      display.rotateY((float)azimuth);
      
      for(int t=0;t<detailT - 1;t++){
        display.beginShape(TRIANGLE_STRIP);
          for(int a=0;a<detailA - 1;a++){
            int index = a + t*detailA;
            int indexS = a + (t+1)*detailA;
            PVector p = spherePoints[index];
            PVector pS = spherePoints[indexS];
            display.fill(sphereLUT[index]);
            display.vertex(p.x,p.y,p.z);
            display.fill(sphereLUT[indexS]);
            display.vertex(pS.x,pS.y,pS.z);
          }
        display.endShape();
      }
    display.endDraw();
  }
  
  public boolean show(){return show(false);}
  public boolean show(boolean polarSnap){
    boolean valueChanged = false;
    if(dragging){
      if(!mousePressed){
        valueChanged = true;
        dragging = false;
        if(snapping){
          snapping = false;
          if (polarSnap){
            setValue(value().roundPolarHarmonic(TAU/8));
          } else {
            setValue(value().round());
          }
        }
      } else {
        azimuth   += (mouseX - pmouseX)*camSensitivity;
        elevation += (mouseY - pmouseY)*camSensitivity;
        azimuth = (azimuth%TAU + TAU) % TAU;
        elevation = Math.min(Math.max(elevation,-Math.PI/2d),Math.PI/2d);
      }
      updateGraphics();
    } else if (mousedOver()){
      if(mousePressed){
        dragging = true;
        if (mouseButton == RIGHT){
          snapping = true;
        }
      }
    }
    
    textSize(16);
    textAlign(CENTER,CENTER);
    image(display,screenPos.x,screenPos.y);
    fill(255);
    text(value().toString(),screenPos.x + screenSize.x/2f,screenPos.y + screenSize.y - 16);
    
    return valueChanged;
  }
}
ComplexFunction[] FUNCTIONS = {
                            new CIdentity(),
                            new CReciprocal(),
                            
                            new CSquare(),
                            new CCube(),
                            new CSqrt(),
                            new CQuartish(),
                            
                            new CExp(),
                            new CLog(),
                            
                            new CSin(),
                            new CCos(),
                            new CTan(),
                            new CSinh(),
                            new CCosh(),
                            new CTanh(),
                            
                            new CASin(),
                            new CACos(),
                            new CATan(),
                            new CASinh(),
                            new CACosh(),
                            new CATanh(),
                            
                            new CBinet(),
                            new CMandel(25),
                            
                            new CGauss(),
                            new CGaussAbs(),
                            new CErf(0.125f/8),
                            
                            new CZeta(30),
                            new CGamma(30),
                            new CReciprocalGamma(30)
                          };



public ListMenu createFunctionList(InteractableFunction[] interactables,ComplexPlane plane){return createFunctionList(interactables,plane,18);}
public ListMenu createFunctionList(InteractableFunction[] interactables,ComplexPlane plane,int txtSize){
  ListItem[] items = new ListItem[FUNCTIONS.length + interactables.length];
  
  final PVector increment = new PVector(0,1.2f*txtSize);//how far it has to move per listItem
  PVector cursor = new PVector(width/2,height/2f - increment.y*items.length/2f);//the position of the first listItem, used to track position
  final float colrate = TAU/items.length;//huechange per item
  
  int maxwidth = 0; //find the maximum label length
  for(int i=0; i<FUNCTIONS.length;i++){maxwidth = max(maxwidth,FUNCTIONS[i].name().length());}
  PVector size = new PVector(maxwidth*txtSize/2f + 40,increment.y); //use maxwidth to set size of buttons, full sides of a rectangle
  
  
  //generate listitems
  for(int i=0; i<FUNCTIONS.length;i++){
    ComplexFunction func = FUNCTIONS[i];
    items[i] = new FunctionListItem(func,plane,cursor,size,i*colrate,0.7f,0.7f);
    cursor = cursor.add(increment);
  }
  for(int i=0; i<interactables.length;i++){
    InteractableFunction func = interactables[i];
    items[i + FUNCTIONS.length] = new InteractableFunctionListItem(func,plane,cursor,size,i*colrate,0.7f,0.7f);
    cursor = cursor.add(increment);
  }
  
  
  return new ListMenu(items,txtSize);
}
class FunctionListItem extends ListItem{
    ComplexFunction function;
    ComplexPlane plane;
    FunctionListItem(ComplexFunction val,ComplexPlane cplane,PVector p,PVector s,float H, float S, float L){
      super(val.name(),p,s,H,S,L);
      function = val;
      plane = cplane;
    }
    
    public void onSelect(){
      normalMode();
      plane.applyFunction(function);
    }
    
    public Object value(){return function;}
    
}

class InteractableFunctionListItem extends ListItem{
  InteractableFunction function;
  ComplexPlane plane;
  InteractableFunctionListItem(InteractableFunction val,ComplexPlane cplane,PVector p,PVector s,float H, float S, float L){
      super(val.name(),p,s,H,S,L);
      function = val;
      plane = cplane;
  }
  public void onSelect(){
    interactableMode(function);
    function.onUpdate();
  }
    
  public Object value(){return function;}
}
public class NotImplementedException extends RuntimeException{
  public NotImplementedException() {super("This feature is not yet implemented.");}
}

interface IntegralLine{
  public boolean improper();
  public Complex value(double t);
}

class RealBounds implements IntegralLine{
  double start, end;
  RealBounds(double _start,double _end){
    start = _start;
    end = _end;
  }
  public boolean improper(){return false;}
  public Complex value(double t){
    return new Complex(start + (end - start)*t,0d);
  }
}
class ComplexBounds implements IntegralLine{
  Complex start, end;
  ComplexBounds(Complex _start,Complex _end){
    start = _start;
    end = _end;
  }
  public boolean improper(){return false;}
  public Complex value(double t){
    return start.add( end.sub(start).mult(t) );
  }
}

class CircleContour implements IntegralLine{
  double radius, turns, offsetAngle;
  CircleContour(double r){radius =r; turns=1; offsetAngle = 0d;}
  CircleContour(double r,double trns,double offset){
    radius =r;
    turns=trns;
    offsetAngle = offset;}
  public boolean improper(){return false;}
  public Complex value(double t){
    return fromPolar(radius,turns*2*Math.PI*t + offsetAngle);
  }
}

class Integral{
  IntegralLine contour;
  ComplexFunction f;
  Integral(ComplexFunction _f,double start, double end){
    f = _f;
    contour = new RealBounds(start,end);
  }
  Integral(ComplexFunction _f,IntegralLine _contour){
    f = _f;
    contour = _contour;
  }
  
  
  public Complex evaluateTrapezoid(int detail){
    if(contour.improper()){throw new NotImplementedException();}
    double lerpStep = 1d/detail;//contour accepts inputs 0 to 1
    Complex total = new Complex(0,0); //running total
    Complex oldT = contour.value(0);
    Complex oldZ = f.f(oldT);
    for(int i=1; i <= detail ;i++){
      //ends at t=1, adds trapezoid from last point to this point
      Complex t = contour.value(i*lerpStep);
      Complex z = f.f(t);
      Complex dt = t.sub(oldT);
      
      total = total.add( z.add(oldZ).mult(0.5d).mult(dt) );
      
      oldT = t;
      oldZ = z;
    }
    return total;    
  }
  
  
  public Complex evaluateSimpson(int detail){
    if(contour.improper()){throw new NotImplementedException();}
    double lerpStep = 1d/detail;//contour accepts inputs 0 to 1
    Complex total = new Complex(0,0); //running total
    Complex oldT = contour.value(0);
    Complex oldZ = f.f(oldT);
    for(int i=1; i <= detail ;i++){
      //ends at t=1, adds trapezoid from last point to this point
      Complex t = contour.value(i*lerpStep);
      Complex midT = t.add(oldT).mult(0.5d);
      Complex z = f.f(t);
      Complex midZTerm = f.f(midT).mult(4d);
      Complex dtFactor = t.sub(oldT).mult(1d/6d);
      
      total = total.add( dtFactor.mult( oldZ.add(midZTerm).add(z) ) );
      
      oldT = t;
      oldZ = z;
    }
    return total;    
  }
}
abstract class InteractableFunction implements ComplexFunction{
  ComplexPlane plane;
  
  InteractableFunction(ComplexPlane _plane){plane = _plane;}
  
  public abstract void show(boolean alt); //show functions should also handle interactivity and apply onUpdate();
  public abstract boolean usingMouse();
  public abstract void reColorise(ComplexColorMap cmap);
  public void onUpdate(){
    plane.applyFunction(this);
  }
}

class BesselFirst extends InteractableFunction{
  Complex[] coefs,pwrs;
  ComplexSpinBox order;
  final int accuracy = 30;
  ComplexFunction rgamma;
  BesselFirst(ComplexPlane _plane,ComplexColorMap cmap,int spinBoxSize){
    super(_plane);
    rgamma = new CReciprocalGamma(50);
    order = new ComplexSpinBox(new Complex(1,0),cmap,(width-spinBoxSize)/2 ,height-spinBoxSize - 5,spinBoxSize,spinBoxSize);
    updateTerms();
  }
  public String name(){return "Bessel-1st of order A: J_A(z)";}
  
  public Complex f(Complex z){
    Complex sum = new Complex(0,0);
    for(int m=0; m<accuracy; m++){
      sum = sum.add(  z.raiseTo(pwrs[m]).mult(coefs[m])  );
    }
    return sum;
  }
  
  public boolean usingMouse(){
    return order.dragging;
  }
  
  public void show(boolean polarSnap){
    final boolean A = order.show(polarSnap);
    text("alpha",order.screenPos.x + order.screenSize.x/2 , order.screenPos.y + 16);
    if( A ){
      onUpdate();
    }
  }
  public void reColorise(ComplexColorMap cmap){
    order.reColorise(cmap);
  }
  
  public void updateTerms(){
    coefs = new Complex[accuracy];
    pwrs = new Complex[accuracy];
    final Complex alpha = order.value();
    final Complex TWO = new Complex(2,0);
    for(int m=0; m<accuracy; m++){
      Complex M = new Complex(m,0);
      pwrs[m] = M.mult(2).add(alpha);
      
      Complex sign = new Complex((m%2 == 0)?1:-1 ,0);// (-1)^m
      Complex rGammaPart = rgamma.f(M.add(alpha).add(1)); // 1/Gamma(m+a+1)
      final double rFactM = 1d / factorial(m); // 1/m!
      final Complex rPowPart = TWO.raiseTo(alpha.add(m).neg()); // 2^-(m+a)
      coefs[m] = sign.mult( rGammaPart ).mult(rFactM).mult(rPowPart);
    }
  }
  
  public @Override
  void onUpdate(){
    updateTerms();
    super.onUpdate();
  }
  
}


class Binomial extends InteractableFunction{
  final int accuracy = 30;
  ComplexSpinBox k;
  ComplexFunction rGamma;
  Binomial(ComplexPlane _plane,ComplexColorMap cmap,int spinBoxSize){
    super(_plane);
    k = new ComplexSpinBox(new Complex(1,0),cmap,(width-spinBoxSize)/2 ,height-spinBoxSize - 5,spinBoxSize,spinBoxSize);
    rGamma = new CReciprocalGamma(accuracy);
  }
  public String name(){return "Binomial: z choose K";}
  
  
  public Complex f(Complex z){
    final Complex K = k.value();
    final Complex gammaN  =  rGamma.f(z.add(1)).reciprocal();
    final Complex gammaD1 =  rGamma.f(K.add(1));
    final Complex gammaD2 =  rGamma.f(z.sub(K).add(1));
    return gammaN.mult(gammaD1).mult(gammaD2);
  }
  
  public boolean usingMouse(){
    return k.dragging;
  }
  
  public void show(boolean polarSnap){
    final boolean K = k.show(polarSnap);
    text("k",k.screenPos.x + k.screenSize.x/2 , k.screenPos.y + 16);
    if( K ){
      onUpdate();
    }
  }
  public void reColorise(ComplexColorMap cmap){
    k.reColorise(cmap);
  }
}


class MobiusTransform extends InteractableFunction{
  ComplexSpinBox a,b,c,d;
  MobiusTransform(ComplexPlane _plane,ComplexColorMap cmap,int spinBoxSize){
    super(_plane);
    final float increment = width/5f;
    final float yPos = height - spinBoxSize - 10;
    float cursor = increment - spinBoxSize/2f;
    a = new ComplexSpinBox(new Complex(1,0),  cmap,  cursor,yPos,  spinBoxSize,spinBoxSize);
    cursor += increment;
    b = new ComplexSpinBox(new Complex(0,0),  cmap,  cursor,yPos,  spinBoxSize,spinBoxSize);
    cursor += increment;
    c = new ComplexSpinBox(new Complex(1,0),  cmap,  cursor,yPos,  spinBoxSize,spinBoxSize);
    cursor += increment;
    d = new ComplexSpinBox(new Complex(1,0),  cmap,  cursor,yPos,  spinBoxSize,spinBoxSize);
    cursor += increment;
  }
  public String name(){return "Mobius: (Az + B) / (Cz + D)";}
  
  public Complex f(Complex z){return ( z.mult(a.value()).add(b.value()) 
                       ).divBy( z.mult(c.value()).add(d.value()) );}
  
  public void show(boolean polarSnap){
    final boolean A = a.show(polarSnap);
    text("A",a.screenPos.x + a.screenSize.x/2 , a.screenPos.y + 16);
    final boolean B = b.show(polarSnap);
    text("B",b.screenPos.x + b.screenSize.x/2 , b.screenPos.y + 16);
    final boolean C = c.show(polarSnap);
    text("C",c.screenPos.x + c.screenSize.x/2 , c.screenPos.y + 16);
    final boolean D = d.show(polarSnap);
    text("D",d.screenPos.x + d.screenSize.x/2 , d.screenPos.y + 16);
    if( A || B || C || D ){
      onUpdate();
    }
  }
  
  public boolean usingMouse(){
    return a.dragging ||b.dragging ||c.dragging ||d.dragging;
  }
  
  public void reColorise(ComplexColorMap cmap){
    a.reColorise(cmap);
    b.reColorise(cmap);
    c.reColorise(cmap);
    d.reColorise(cmap);
  }
}
class ListMenu{
  int txtSize;
  ListItem[] items;
  int selectedIndex = 0;
  ListMenu(ListItem[] _items,int textSize){
    items = _items;
    txtSize = textSize;
  }
  
  public boolean show(){//returns true on a new selection, return value can otherwise be ignored
    textAlign(CENTER,CENTER);
    textSize(txtSize);
    rectMode(CENTER);
    noStroke();
    for(int i=0; i<items.length;i++){
      ListItem item = items[i];
      if(item.mousedOver() && mousePressed){
        select(i);
        return true;
      }
      item.show(selectedIndex == i);
    }
    return false;
  }
  
  public void select(int index){
    selectedIndex = index;
    items[index].onSelect();
  }
}

abstract class ListItem{
    PVector pos,size;
    int normal,hovered,selected;
    String label;
    ListItem(String lbl,PVector p,PVector s,float H, float S, float L){
      label = lbl;
      pos = p.copy();
      size = s.copy();
      normal = HSL(H,S,L,0.7f);
      hovered = HSL(H,sqrt(S),sqrt(L),1f);
      selected = HSL(H,S*S*S,sqrt(sqrt(L)));
    }
    
    public abstract void onSelect();
    public abstract Object value();
    
    public void show(boolean isSelected){
      if(mousedOver()){
        fill(hovered);
      }else if(isSelected){
        fill(selected);
      } else {
        fill(normal);
      }
      rect(pos.x,pos.y,size.x,size.y);
      fill(255);
      text(label,pos.x,pos.y - size.y/10);
    }
    public boolean mousedOver(){
      float relX = abs(mouseX - pos.x);
      float relY = abs(mouseY - pos.y);
      return relX < size.x/2d && relY < size.y/2f;
    }
}


  
public long fallingFactorial(int x, int p){
  long out = 1;
  for (int k=0;k<p;k++){
    out *= x-k;
  }
  return out;
}

public long factorial(int x){
  long out = 1;
  for (int k=1;k<=x;k++){
    out *= k;
  }
  return out;
}
  public void settings() {  fullScreen(P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "RiemannSphere" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
